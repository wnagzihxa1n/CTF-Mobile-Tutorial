package net.bluelotus.tomorrow.easyandroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.wnagzihxain.demo.R;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("lhm");
    }

    public native String stringFromJNI2(int number);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        Toast.makeText(this, stringFromJNI2(1616384), Toast.LENGTH_LONG).show();
        Log.i("toT0C", stringFromJNI2(1616384));
    }
}
